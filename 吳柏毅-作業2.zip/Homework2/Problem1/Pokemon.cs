﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem1
{
    public class Pokemon
    {
        public int NationalNo;
        public string Name;
        public string Type;
        public string Species;
        public float Height;
        public float Weight;
        public string Abilities;
        public string LocalNo1;
        public string LocalNo2;
        public string LocalNo3;
        public string LocalNo4;
        public string Japanese;
    }
}