﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem1
{
    public class TEST
    {
        public string NationalNo;

        public string Type;

        public string Species;

        public string Height;

        public string Weight;

        public string Abilities;

        public string LocalNo1;

        public string LocalNo2;

        public string LocalNo3;

        public string LocalNo4;

        public string Japanese;
    }
}