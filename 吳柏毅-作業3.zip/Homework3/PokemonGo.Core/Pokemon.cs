﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PokemonGo.Core
{
    public class Pokemon
    {
        public string Name;                 //宣告變數"Name"為"string(字串)"型別
        public int HP;                      //宣告變數"Name"為"string(字串)"型別
        public int CurrentHP;               //宣告變數"Name"為"string(字串)"型別
    }
}