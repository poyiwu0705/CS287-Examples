﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PokemonGo.Core
{
    public class Potion
    {
        public string Name;                     //宣告變數"Name"為"string(字串)"型別
        public string Description;              //宣告變數"Description"為"string(字串)"型別
        public int RestoringHP;                 //宣告變數"RestoringHP"為"int(整數)"型別
        public int Count;                       //宣告變數"Count"為"int(整數)"型別
    }
}